#ifndef _ITEMS_H
#define _ITEMS_H

// Add items as needed, with 14K items in the database this 
// file would be huge if we put all of them in here.

// Ninja tools
#define ITEM_UCHITAKE (1161)
#define ITEM_TSURARA (1164)
#define ITEM_KAWAHORI_OGI (1167)
#define ITEM_MAKIBISHI (1170)
#define ITEM_HIRAISHIN (1173)
#define ITEM_MIZU_DEPPO (1176)
#define ITEM_RYUNO (2644)
#define ITEM_MOKUJIN (2970)
#define ITEM_SANJAKU_TENUGUI (2553)
#define ITEM_KABENRO (2642)
#define ITEM_SHINOBI_TABI (1194)
#define ITEM_SHIHEI (1179)
#define ITEM_SOSHI (2555)
#define ITEM_KODOKU (1191)
#define ITEM_KAGINAWA (1185)
#define ITEM_JUSATSU (1182)
#define ITEM_SAIRUI_RAN (1188)
#define ITEM_JINKO (2643)
#define ITEM_INOSHISHINOFUDA (2971)
#define ITEM_SHIKANOFUDA (2972)
#define ITEM_CHONOFUDA (2973)
#define ITEM_RANKA (8803)
#define ITEM_FURUSUMI (8804)

#endif
